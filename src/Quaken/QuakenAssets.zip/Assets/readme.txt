Top-down asset pack by Ruthenium
Link to the prototype: https://jukaio.itch.io/the-quacken

Contents of pack: 
duck animations (idle, walk, hide in a barrel, crawl)
kitchen tiles (room tiles and decoration tiles)
manor tiles (room tiles and decoration tiles)
tunnel tiles (room tiles)
UI buttons for controls
mockups of kitchen and manor for reference 

Contact:
Twitter: @dead_madman
Itch.io: https://deadmadman.itch.io